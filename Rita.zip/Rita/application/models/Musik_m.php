<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Musik_m extends CI_Model {

    private $table = 'musik'; // Nama tabel di database

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function get_all()
    {
        return $this->db->get($this->table)->result_array();
    }

    public function insert_musik($data)
    {
        return $this->db->insert($this->table, $data);
    }

    public function get_by_id($id)
    {
        return $this->db->get_where($this->table, ['id_alat_musik' => $id])->row_array();
    }

    public function update_musik($id, $data)
    {
        $this->db->where('id_alat_musik', $id);
        return $this->db->update($this->table, $data);
    }

    public function delete_musik($id)
    {
        $this->db->where('id_alat_musik', $id);
        return $this->db->delete($this->table);
    }
}