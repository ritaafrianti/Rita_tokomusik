<?php $this->load->view('template/head'); ?>
<?php $this->load->view('template/sidebar'); ?>

<div class="main-panel">
    <div class="content">
        <div class="container-fluid">
            <h4 class="page-title">DATA ALAT MUSIK</h4>
            <div class="row">
                <div class="col-md-3">
                    <div class="card card-stats card-warning">
                        </div>
                </div>
            </div>
            <div class="card-body">
                <h5 class="card-title"></h5>
                <a href="<?php echo base_url('index.php/musik/tambah'); ?>" class="btn btn-primary mb-3">Tambah Alat Musik</a>
                <div class="table-responsive" style="overflow-x: auto;">
                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>NO</th>
                                <th>NAMA ALAT MUSIK</th>
                                <th>MERK</th>
                                <th>HARGA</th>
                                <th>STOK</th>
                                <th>AKSI</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($musik)): ?>
                                <tr><td colspan="6">Tidak ada data alat musik.</td></tr>
                            <?php else: ?>
                                <?php $no = 1; ?>
                                <?php foreach ($musik as $row): ?>
                                    <tr>
                                        <td><?php echo $no++; ?></td>
                                        <td><?php echo $row['nama_alat_musik']; ?></td>
                                        <td><?php echo $row['merk']; ?></td>
                                        <td>Rp <?php echo number_format($row['harga'], 2, ',', '.'); ?></td>
                                        <td><?php echo $row['stok']; ?></td>
                                        <td>
                                            <a href="<?php echo site_url('index.php/musik/edit/' . $row['id_alat_musik']); ?>" class="btn btn-sm btn-warning">Edit</a> |
                                            <a href="<?php echo site_url('index.php/musik/hapus/' . $row['id_alat_musik']); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
<?php $this->load->view('template/footer'); ?>