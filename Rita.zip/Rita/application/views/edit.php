<?php $this->load->view('template/head'); ?>
<?php $this->load->view('template/sidebar'); ?>

<div class="main-panel">
    <div class="content">
        <div class="container-fluid">
            <h4 class="page-title">EDIT DATA ALAT MUSIK</h4>
            <div class="row">
                <div class="col-md-3">
                    <div class="card card-stats card-warning">
                        </div>
                </div>
            </div>
            <div class="card-body">
                <h5 class="card-title"></h5>
                <form action="<?php echo site_url('index.php/musik/edit_aksi'); ?>" method="POST">
                    <input type="hidden" name="id_alat_musik" value="<?php echo $musik['id_alat_musik']; ?>">
                    <div class="mb-3">
                        <label for="nama_alat_musik" class="form-label">Nama Alat Musik</label>
                        <input type="text" class="form-control" id="nama_alat_musik" name="nama_alat_musik" value="<?php echo $musik['nama_alat_musik']; ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="merk" class="form-label">Merk</label>
                        <input type="text" class="form-control" id="merk" name="merk" value="<?php echo $musik['merk']; ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="harga" class="form-label">Harga</label>
                        <input type="number" class="form-control" id="harga" name="harga" step="0.01" value="<?php echo $musik['harga']; ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="stok" class="form-label">Stok</label>
                        <input type="number" class="form-control" id="stok" name="stok" value="<?php echo $musik['stok']; ?>" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                    <a href="<?php echo base_url('index.php/musik'); ?>" class="btn btn-secondary">Batal</a>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $this->load->view('template/footer'); ?>