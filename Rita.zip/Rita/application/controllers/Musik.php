<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Musik extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Musik_m');
    }

    public function index()
    {
        $data['musik'] = $this->Musik_m->get_all();
        $this->load->view('musik', $data);
    }

    public function tambah()
    {
        $this->load->view('tambah');
    }

    public function tambah_aksi()
    {
        $nama_alat_musik = $this->input->post('nama_alat_musik');
        $merk = $this->input->post('merk');
        $harga = $this->input->post('harga');
        $stok = $this->input->post('stok');

        $data = array(
            'nama_alat_musik' => $nama_alat_musik,
            'merk' => $merk,
            'harga' => $harga,
            'stok' => $stok
        );

        $this->Musik_m->insert_musik($data);
        redirect('index.php/musik');
    }

    public function edit($id)
    {
        $data['musik'] = $this->Musik_m->get_by_id($id);
        $this->load->view('edit', $data);
    }

    public function edit_aksi()
    {
        $id_alat_musik = $this->input->post('id_alat_musik');
        $nama_alat_musik = $this->input->post('nama_alat_musik');
        $merk = $this->input->post('merk');
        $harga = $this->input->post('harga');
        $stok = $this->input->post('stok');

        $data = array(
            'nama_alat_musik' => $nama_alat_musik,
            'merk' => $merk,
            'harga' => $harga,
            'stok' => $stok
        );

        $this->Musik_m->update_musik($id_alat_musik, $data);
        redirect('index.php/musik');
    }

    public function hapus($id)
    {
        $this->Musik_m->delete_musik($id);
        redirect('index.php/musik');
    }
}